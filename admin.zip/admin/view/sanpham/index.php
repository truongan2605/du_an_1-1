
// include "../header.php";
// controller dùng để chọn phần nào trong các thư mục sẽ hiển thị trên trang index
// if (isset($_GET['act'])) {

//     $act = $_GET['act'];

//     switch ($act) {
//         case 'addsp':
//             include 'add.php';
//             break;
//         case 'updatesp':
//             include 'update.php';
//             break;
//         default:

//             break;
//     }
// } else {
//     include "../sanpham/list.php";
// }
